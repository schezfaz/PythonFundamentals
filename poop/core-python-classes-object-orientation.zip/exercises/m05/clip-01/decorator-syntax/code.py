
@decorator
def decorated_function():
    # . . .
