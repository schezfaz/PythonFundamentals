def typename(obj):
    return type(obj).__name__
