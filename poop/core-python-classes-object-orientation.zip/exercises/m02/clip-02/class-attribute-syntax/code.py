class MyClass:

    # Define class attributes in the class block
    my_class_attribute = "class attributes go here"
    MY_CONSTANT = "they are often class-specific contants"

    def __init__(self):
        self.my_instance_attribute = "instance attributes here"
