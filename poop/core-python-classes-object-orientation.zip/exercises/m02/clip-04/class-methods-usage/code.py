class MyClass:

    attribute = "class attribute"

    @classmethod
    def my_class_method(cls, message):
        cls.attribute = message
