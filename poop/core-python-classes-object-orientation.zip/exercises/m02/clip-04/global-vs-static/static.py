class SplineReticulator:

    def reticulate(x, y):
        return self._tricky_math(x, y)

    @staticmethod
    def _tricky_math(x, y):
        return 2 * x**2 - 4*y
