class SplineReticulator:

    def reticulate(x, y):
        return _tricky_math(x, y)

# Global function
def _tricky_math(x, y):
    return 2 * x**2 - 4*y
