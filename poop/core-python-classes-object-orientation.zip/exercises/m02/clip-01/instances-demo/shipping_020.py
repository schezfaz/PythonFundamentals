class ShippingContainer:

    def __init__(self):
        pass
