class ShippingContainer:

    def __init__(self, owner_code):
        self.owner_code = owner_code
