class Base:
    def __init__(self):
        print('Base initializer')

    def f(self):
        print('Base.f()')
