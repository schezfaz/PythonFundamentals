class Animal:
    @classmethod
    def description(cls):
        return "An animal"
